function validacion() {
    var nombre = document.getElementById("nombre")[0].value;
    if (nombre.trim() === "") {
        alert("El campo de nombre no puede estar vacío.");
        return false;
    }
    return true;
}
